### Parameter config summary 
<h2>c302 simulation</h2>
<p>Parameter set: <b>C0</b>; configuration: <b>Syns</b></p>
<p>Generated on: Mon, 30 Mar 2026 with c302 v0.12.0</p><br/>
<table>

<tr>
  <td><a href="images/neurons_C0_Syns.png"><img alt=" " src="images/neurons_C0_Syns.png" height="320"/></a></td>
  <td><a href="images/traces_neuron_Syns_C0.png"><img alt=" " src="images/traces_neuron_Syns_C0.png" height="320"/></a></td>
</tr>

<tr>
  <td><a href="images/neuron_activity_C0_Syns.png"><img alt=" " src="images/neuron_activity_C0_Syns.png" height="320"/></a></td>
  <td><a href="images/traces_neuron_activity_Syns_C0.png"><img alt=" " src="images/traces_neuron_activity_Syns_C0.png" height="320"/></a></td>
</tr>

<tr>
  <td><a href="images/muscles_C0_Syns.png"><img alt=" " src="images/muscles_C0_Syns.png" height="320"/></a></td>
  <td><a href="images/traces_muscles_Syns_C0.png"><img alt=" " src="images/traces_muscles_Syns_C0.png" height="320"/></a></td>
</tr>

<tr>
  <td><a href="images/muscle_activity_C0_Syns.png"><img alt=" " src="images/muscle_activity_C0_Syns.png" height="320"/></a></td>
  <td><a href="images/traces_muscles_activity_Syns_C0.png"><img alt=" " src="images/traces_muscles_activity_Syns_C0.png" height="320"/></a></td>
</tr>
</table>
<table>

<tr><td><a href="images/c302_C0_Syns_exc_to_neurons.png"><img alt=" " src="images/c302_C0_Syns_exc_to_neurons.png" height="320"/></a></td>

  <td><a href="images/c302_C0_Syns_inh_to_neurons.png"><img alt=" " src="images/c302_C0_Syns_inh_to_neurons.png" height="320"/></a></td>

  <td><a href="images/c302_C0_Syns_elec_neurons_neurons.png"><img alt=" " src="images/c302_C0_Syns_elec_neurons_neurons.png" height="320"/></a></td></tr>

<tr><td><a href="images/c302_C0_Syns_exc_to_muscles.png"><img alt=" " src="images/c302_C0_Syns_exc_to_muscles.png" height="320"/></a></td>

  <td><a href="images/c302_C0_Syns_inh_to_muscles.png"><img alt=" " src="images/c302_C0_Syns_inh_to_muscles.png" height="320"/></a></td></tr>
</table>
