### Parameter config summary 
<h2>c302 simulation</h2>
<p>Parameter set: <b>W2D</b>; configuration: <b>Pharyngeal</b></p>
<p>Generated on: Mon, 30 Mar 2026 with c302 v0.12.0</p><br/>
<table>

<tr>
  <td><a href="images/neurons_W2D_Pharyngeal.png"><img alt=" " src="images/neurons_W2D_Pharyngeal.png" height="320"/></a></td>
  <td><a href="images/traces_neuron_Pharyngeal_W2D.png"><img alt=" " src="images/traces_neuron_Pharyngeal_W2D.png" height="320"/></a></td>
</tr>

<tr>
  <td><a href="images/neuron_activity_W2D_Pharyngeal.png"><img alt=" " src="images/neuron_activity_W2D_Pharyngeal.png" height="320"/></a></td>
  <td><a href="images/traces_neuron_activity_Pharyngeal_W2D.png"><img alt=" " src="images/traces_neuron_activity_Pharyngeal_W2D.png" height="320"/></a></td>
</tr>

<tr>
  <td><a href="images/muscles_W2D_Pharyngeal.png"><img alt=" " src="images/muscles_W2D_Pharyngeal.png" height="320"/></a></td>
  <td><a href="images/traces_muscles_Pharyngeal_W2D.png"><img alt=" " src="images/traces_muscles_Pharyngeal_W2D.png" height="320"/></a></td>
</tr>

<tr>
  <td><a href="images/muscle_activity_W2D_Pharyngeal.png"><img alt=" " src="images/muscle_activity_W2D_Pharyngeal.png" height="320"/></a></td>
  <td><a href="images/traces_muscles_activity_Pharyngeal_W2D.png"><img alt=" " src="images/traces_muscles_activity_Pharyngeal_W2D.png" height="320"/></a></td>
</tr>
</table>
<table>

<tr><td><a href="images/c302_W2D_Pharyngeal_exc_to_neurons.png"><img alt=" " src="images/c302_W2D_Pharyngeal_exc_to_neurons.png" height="320"/></a></td>

  <td><a href="images/c302_W2D_Pharyngeal_inh_to_neurons.png"><img alt=" " src="images/c302_W2D_Pharyngeal_inh_to_neurons.png" height="320"/></a></td>

  <td><a href="images/c302_W2D_Pharyngeal_elec_neurons_neurons.png"><img alt=" " src="images/c302_W2D_Pharyngeal_elec_neurons_neurons.png" height="320"/></a></td></tr>

<tr><td><a href="images/c302_W2D_Pharyngeal_exc_to_muscles.png"><img alt=" " src="images/c302_W2D_Pharyngeal_exc_to_muscles.png" height="320"/></a></td>

  <td><a href="images/c302_W2D_Pharyngeal_inh_to_muscles.png"><img alt=" " src="images/c302_W2D_Pharyngeal_inh_to_muscles.png" height="320"/></a></td></tr>
</table>
