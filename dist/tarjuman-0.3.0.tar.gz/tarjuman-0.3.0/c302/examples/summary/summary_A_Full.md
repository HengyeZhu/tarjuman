### Parameter config summary 
<h2>c302 simulation</h2>
<p>Parameter set: <b>A</b>; configuration: <b>Full</b></p>
<p>Generated on: Mon, 30 Mar 2026 with c302 v0.12.0</p><br/>
<table>

<tr>
  <td><a href="images/neurons_A_Full.png"><img alt=" " src="images/neurons_A_Full.png" height="320"/></a></td>
  <td><a href="images/traces_neuron_Full_A.png"><img alt=" " src="images/traces_neuron_Full_A.png" height="320"/></a></td>
</tr>

<tr>
  <td><a href="images/neuron_activity_A_Full.png"><img alt=" " src="images/neuron_activity_A_Full.png" height="320"/></a></td>
  <td><a href="images/traces_neuron_activity_Full_A.png"><img alt=" " src="images/traces_neuron_activity_Full_A.png" height="320"/></a></td>
</tr>

<tr>
  <td><a href="images/muscles_A_Full.png"><img alt=" " src="images/muscles_A_Full.png" height="320"/></a></td>
  <td><a href="images/traces_muscles_Full_A.png"><img alt=" " src="images/traces_muscles_Full_A.png" height="320"/></a></td>
</tr>

<tr>
  <td><a href="images/muscle_activity_A_Full.png"><img alt=" " src="images/muscle_activity_A_Full.png" height="320"/></a></td>
  <td><a href="images/traces_muscles_activity_Full_A.png"><img alt=" " src="images/traces_muscles_activity_Full_A.png" height="320"/></a></td>
</tr>
</table>
<table>

<tr><td><a href="images/c302_A_Full_exc_to_neurons.png"><img alt=" " src="images/c302_A_Full_exc_to_neurons.png" height="320"/></a></td>

  <td><a href="images/c302_A_Full_inh_to_neurons.png"><img alt=" " src="images/c302_A_Full_inh_to_neurons.png" height="320"/></a></td>

  <td><a href="images/c302_A_Full_elec_neurons_neurons.png"><img alt=" " src="images/c302_A_Full_elec_neurons_neurons.png" height="320"/></a></td></tr>

<tr><td><a href="images/c302_A_Full_exc_to_muscles.png"><img alt=" " src="images/c302_A_Full_exc_to_muscles.png" height="320"/></a></td>

  <td><a href="images/c302_A_Full_inh_to_muscles.png"><img alt=" " src="images/c302_A_Full_inh_to_muscles.png" height="320"/></a></td></tr>
</table>
