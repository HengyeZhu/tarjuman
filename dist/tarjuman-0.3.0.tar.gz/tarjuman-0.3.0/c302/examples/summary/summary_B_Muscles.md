### Parameter config summary 
<h2>c302 simulation</h2>
<p>Parameter set: <b>B</b>; configuration: <b>Muscles</b></p>
<p>Generated on: Mon, 30 Mar 2026 with c302 v0.12.0</p><br/>
<table>

<tr>
  <td><a href="images/neurons_B_Muscles.png"><img alt=" " src="images/neurons_B_Muscles.png" height="320"/></a></td>
  <td><a href="images/traces_neuron_Muscles_B.png"><img alt=" " src="images/traces_neuron_Muscles_B.png" height="320"/></a></td>
</tr>

<tr>
  <td><a href="images/neuron_activity_B_Muscles.png"><img alt=" " src="images/neuron_activity_B_Muscles.png" height="320"/></a></td>
  <td><a href="images/traces_neuron_activity_Muscles_B.png"><img alt=" " src="images/traces_neuron_activity_Muscles_B.png" height="320"/></a></td>
</tr>

<tr>
  <td><a href="images/muscles_B_Muscles.png"><img alt=" " src="images/muscles_B_Muscles.png" height="320"/></a></td>
  <td><a href="images/traces_muscles_Muscles_B.png"><img alt=" " src="images/traces_muscles_Muscles_B.png" height="320"/></a></td>
</tr>

<tr>
  <td><a href="images/muscle_activity_B_Muscles.png"><img alt=" " src="images/muscle_activity_B_Muscles.png" height="320"/></a></td>
  <td><a href="images/traces_muscles_activity_Muscles_B.png"><img alt=" " src="images/traces_muscles_activity_Muscles_B.png" height="320"/></a></td>
</tr>
</table>
<table>

<tr><td><a href="images/c302_B_Muscles_exc_to_neurons.png"><img alt=" " src="images/c302_B_Muscles_exc_to_neurons.png" height="320"/></a></td>

  <td><a href="images/c302_B_Muscles_inh_to_neurons.png"><img alt=" " src="images/c302_B_Muscles_inh_to_neurons.png" height="320"/></a></td>

  <td><a href="images/c302_B_Muscles_elec_neurons_neurons.png"><img alt=" " src="images/c302_B_Muscles_elec_neurons_neurons.png" height="320"/></a></td></tr>

<tr><td><a href="images/c302_B_Muscles_exc_to_muscles.png"><img alt=" " src="images/c302_B_Muscles_exc_to_muscles.png" height="320"/></a></td>

  <td><a href="images/c302_B_Muscles_inh_to_muscles.png"><img alt=" " src="images/c302_B_Muscles_inh_to_muscles.png" height="320"/></a></td></tr>
</table>
